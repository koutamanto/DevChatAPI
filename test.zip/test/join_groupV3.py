from join_group import join_group
from login import login, loginV2

uid = "uaa40e1d4402111e"
join_group(uid, input("gid:"))