from join_group import join_group
from login import login

#uid = login()["uid"]
join_group("u7bd413bc2e1411e", "g2b5f30a6347c11e")
