from requests.api import get
from get_list import get_list

get_list()