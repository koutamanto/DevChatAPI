import requests, json
from datetime import datetime
from lib.get_messagesV2 import get_messagesV3
from time import sleep
from lib.login import loginV2
from lib.send_message import send_messageV2
from lib.send_html_message import send_html_messageV2
from lib.send_html_with_url import send_html_message_with_urlV2
from lib.get_list import get_listV2

cl_uid = loginV2("email", "password")["uid"] #email:メールアドレス password:パスワードで置き換え
while True:
    #try:
    sleep(1)
    joined_groups = loginV2("email", "password")["group"] #email:メールアドレス password:パスワードで置き換え
    for group in joined_groups:
        sleep(1)
        gid = group["gid"]
        messages = get_messagesV3("email", "password", gid) #email:メールアドレス password:パスワードで置き換え
        last_message = messages[-1]
        text = last_message["content"]
        if text == "こんにちは":
            send_messageV2(cl_uid, gid, "こんにちは～")
        elif text == "おはよう":
            send_messageV2(cl_uid, gid, "は？(困惑)")
        elif text.startswith("get:"):
            url = text.replace("get:", "")
            print(url)
            send_html_message_with_urlV2(cl_uid, gid, url)
        elif text.startswith("mget:"):
            url = text.replace("mget:", "")
            r = requests.get(url=url).text
            send_html_messageV2(cl_uid, gid, r)
        elif text in ["now", "今何時？", "現在時刻"]:
            send_messageV2(cl_uid, gid, datetime.now().strftime('%Y/%m/%d %H:%M:%S'))
    #except Exception as e:
    #    print(e)