import requests, json

datas = {
    "type": "unregister",
    "uid": input("uid:"),
    "password": input("password:")
}

r = requests.post(verify=False, url="https://devchat.jp/unregister", json=datas)
print(r, r.text)
r_datas = json.loads(r.text)
print(r_datas)