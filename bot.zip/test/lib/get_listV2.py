from requests.api import get
from lib.get_list import get_list

get_list()