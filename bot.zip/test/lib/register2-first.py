import requests

datas_for_first = {
  "type": "first_sign_up",
  "user_name": "KJunkie",
  "mail_address": "devchatlog@gmail.com",
  "pass_word": "Kouta1014"
}

r = requests.post(verify=False, url="https://devchat.jp/register", json=datas_for_first)
print(r, r.text)