class Config:
    def __init__(self):
        self.base_url = "https://devchat.jp"
        self.upload_icon = "/upload_icon"
        self.upload_icon_url = self.base_url + self.upload_icon