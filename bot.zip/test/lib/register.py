from flask import json
import requests

datas = {
  "type": "sign_up",
  "user_name": "KJunkie",
  "mail_address": "devchatlog@gmail.com",
  "pass_word": "Kouta1014"
}
r = requests.post(verify=False, url="https://devchat.jp/register", json=datas)
print(r, r.text)