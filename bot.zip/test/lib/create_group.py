import json
import requests
from lib.login import login
def create_group(name):
  uid = login()["uid"]
  datas = {
    "type": "create_group",
    "uid""": uid,
    "name": name
  }
  r = requests.post(verify=False, url="https://devchat.jp/create_group", json=datas)
  r_datas = json.loads(r.text)
  print(r, r_datas)
  return r_datas