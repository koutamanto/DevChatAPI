import requests, json
from lib.login import login
from lib.get_list import get_list
from lib.get_messages import get_messages
def send_html_messageV2(uid, to, content):
    datas = {"type": "send_html_message", "sender":uid, "to":to, "message":{"type":"html", "content":content}}
    r = requests.post(verify=False, url="https://devchat.jp/send_html_message", json=datas)
    return json.loads(r.text)
    #print(r, r.text)
    #get_messages()