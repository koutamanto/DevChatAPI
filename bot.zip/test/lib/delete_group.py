import json, requests

gid = input("gid:")
r = requests.post(verify=False, url="https://devchat.jp/delete_group", json={"type": "delete_group", "gid":gid})

print(r, r.text)