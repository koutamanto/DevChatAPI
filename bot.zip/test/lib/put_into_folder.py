import requests, json
from lib.login import login
from lib.get_list import get_list

uid = login()["uid"]
talk_list = get_list()

datas = {
    "type":"put_into_folder",
    "uid": uid,
    "gid": input("gid:"),
    "fid": input("fid:")
}
r = requests.post(verify=False, url="https://devchat.jp/put_into_folder", json=datas)
r_datas = json.loads(r.text)
print(r, r_datas)