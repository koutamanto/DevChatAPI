import requests, json
from lib.login import login

#uid = login()["uid"]
datas = {
    "type":"delete_folder",
    "uid":"u7bd413bc2e1411e",
    "fid":"f02d25536377011e	"
}
r = requests.post(verify=False, url="https://devchat.jp/delete_folder", json=datas)
r_datas = json.loads(r.text)
print(r, r_datas)