from create_group import create_group


datas = create_group(input("group_name:"))
print(datas)