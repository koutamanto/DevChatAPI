import requests, json
from lib.config import Config

def add_friend(from_uid, target_uid):
    datas = {
        "type": "add_friend",
        "from_uid":from_uid,
        "target_uid":target_uid
    }
    r = requests.post(Config().base_url + "/add_friend", json=datas)
    r_datas = json.loads(r.text)
    print(r, r_datas)
    return r_datas