import requests, json
from lib.config import Config

config = Config()

def leave_group(uid, gid):
    datas = {
        "type": "leave_group",
        "uid":uid,
        "gid":gid
    }
    r = requests.post(verify=False, url="https://devchat.jp" + "/leave_group", json=datas)
    r_datas = json.loads(r.text)
    print(r, r_datas)
    return r_datas